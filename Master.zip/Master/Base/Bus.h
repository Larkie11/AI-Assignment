#ifndef BUS_H
#define BUS_H

class Bus
{
	enum STATES
	{
		S_WALKING,
	};
};

#endif