#pragma once

enum States
{
	//1 fsm
	SPAWNING,
	SPAWNED,
	ROTTING,
	DECAYED,
};
