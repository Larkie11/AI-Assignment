WASD - move forward, left, backward, right
1,2 - toggle front face culling
3,4 - toggle wireframe mode

Left Mouse Button - Shoot Bullet